using RBot;

public class ExeScript {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.PrivateRooms = true;
		bot.Options.ExitCombatBeforeQuest = true;
		bot.Options.LagKiller = true;
		
		bot.Skills.StartTimer();
		
		bot.Player.LoadBank();
		bot.Bank.ToInventory("Blinding Bow of Destiny");
		bot.Bank.ToInventory("Blinding Light Fragments");
		bot.Bank.ToInventory("Bright Aura");
		bot.Bank.ToInventory("Blinding Aura");
		bot.Bank.ToInventory("Bone Dust");
		bot.Bank.ToInventory("Undead Essence");
		bot.Bank.ToInventory("Undead Energy");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2174);
			
			bot.Player.Join("battleunderb");
			bot.Player.HuntForItem("Skeleton Warrior", "Blinding Light Fragments", 10);
			
			bot.Player.Jump("Wait", "Spawn");
			bot.Wait.ForCombatExit();
			bot.Quests.Complete(2174);
			
			bot.Wait.ForDrop("Bright Aura");
			bot.Player.Pickup("Bright Aura", "Blinding Aura", "Bone Dust", "Undead Essence", "Undead Energy");
		}
	}
}
