using System;
using RBot;
using System.Windows.Forms;

public class ExeScript 
{

	//-----------EDIT BELOW-------------//		
	public string[] Sell_List = 
	{
		"Replace This",
		"Replace This",
		"Replace This",
		"Replace This",
		"Replace This"
	};
	//-----------EDIT ABOVE-------------//	
	public ScriptInterface bot => ScriptInterface.Instance;
	public void ScriptMain(ScriptInterface bot)
	{
		bot.Options.SafeTimings = true;
		bot.Skills.StartTimer();

		foreach (string item in Sell_List)
		{		
			while(bot.Inventory.Contains(item))
			{
				bot.Shops.SellItem(item);
			}
		}
		StopBot($"Successfully sold all items.");
	}
	
	public void StopBot(string Text = "Bot stopped successfully.")
	{
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Bot stopped successfully.");
		Console.WriteLine(Text);
		MessageBox.Show(Text);
		bot.Exit();
	}
}
