using RBot;

public class ExeScript {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.PrivateRooms = true;
		bot.Options.ExitCombatBeforeQuest = true;
		bot.Options.LagKiller = true;
		
		bot.Skills.StartTimer();
		
		bot.Player.LoadBank();
		bot.Bank.ToInventory("Blinding Mace of Destiny");
		bot.Bank.ToInventory("Blinding Light Fragments");
		bot.Bank.ToInventory("Brilliant Aura");
		bot.Bank.ToInventory("Blinding Aura");
		bot.Bank.ToInventory("Bone Dust");
		bot.Bank.ToInventory("Undead Essence");
		bot.Bank.ToInventory("Undead Energy");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2176);
			
			bot.Player.Join("battleunderb");
			bot.Player.HuntForItem("Skeleton Warrior", "Blinding Light Fragments", 10);
			
			bot.Player.Jump("Wait", "Spawn");
			bot.Wait.ForCombatExit();
			bot.Quests.Complete(2176);
			
			bot.Wait.ForDrop("Brilliant Aura");
			bot.Player.Pickup("Brilliant Aura", "Blinding Aura", "Bone Dust", "Undead Essence", "Undead Energy");
		}
	}
}
