# AQW Datas
These are the shop IDs and the Quest IDs.

Quest IDs are updated regularly.
If you know a shop ID that isn't here, feel free to ping "@Bloom Autist" in the discord server.