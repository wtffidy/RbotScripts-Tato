using System;
using RBot;
using System.Collections.Generic;

public class Escherion
{
	//-----------EDIT BELOW-------------//
	public int MapNumber = 2142069;
	public readonly int[] SkillOrder = { 3, 2, 4 };
	public int SaveStateLoops = 8700;
	public int TurnInAttempts = 10;
	public string[] RequiredItems = { };
	public string[] EquippedItems = { };
	//-----------EDIT ABOVE-------------//


	public int FarmLoop;
	public int SavedState;
	public ScriptInterface bot => ScriptInterface.Instance;
	public void ScriptMain(ScriptInterface bot)
	{
		if (bot.Player.Cell != "Wait") bot.Player.Jump("Wait", "Spawn");

		ConfigureBotOptions();
		ConfigureLiteSettings();

		SkillList(SkillOrder);
		EquipList(EquippedItems);
		UnbankList(RequiredItems);
		CheckSpace(RequiredItems);
		GetDropList(RequiredItems);
		
		bot.SendPacket("%xt%zm%getQuests%7%165%%166%167%168%169%");
		
		while (!bot.Player.Loaded) { }
		{
		A:
			if (bot.Quests.IsAvailable(272))
				goto Escherion;
			else
				goto B;
		Escherion:
			ItemFarm("Defeated Escherion", 1, "escherion", "Boss", "Left", true, 272, true, "Escherion");
			ExitCombat();
			bot.Quests.EnsureComplete(272);
			goto End2;
		B:
			if (bot.Quests.IsAvailable(271))
				goto Hydra;
			else
				goto C;
		Hydra:
			if (bot.Map.Name != "hydra".ToLower()) SafeMapJoin("hydra".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(271);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%79252%50%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%79252%51%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%79252%52%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(271);
			goto Escherion;
		C:
			if (bot.Quests.IsAvailable(270))
				goto Keythree;
			else
				goto D;
		Keythree:
			ItemFarm("Gargoyle Door Key", 1, "relativity", "Enter", "Spawn", true, 270, true, "Head Gargoyle");
			ExitCombat();
			bot.Quests.EnsureComplete(270);
			goto Hydra;
		D:
			if (bot.Quests.IsAvailable(269))
				goto Keytwo;
			else
				goto E;
		Keytwo:
			ItemFarm("Imp Door Key", 6, "mobius", "Enter", "Spawn", true, 269, true, "Fire Imp");
			ExitCombat();
			bot.Quests.EnsureComplete(269);
			goto Keythree;
		E:
			if (bot.Quests.IsAvailable(268))
				goto Keyone;
			else
				goto F;
		Keyone:
			ItemFarm("Cyclops Door Key", 1, "mobius", "Enter", "Spawn", true, 268, true, "Cyclops Raider");
			ExitCombat();
			bot.Quests.EnsureComplete(268);
			goto Keytwo;
		F:
			if (bot.Quests.IsAvailable(265))
				goto Box;
			else
				goto G;
		Box:
			ItemFarm("Cardboard Box", 4, "faerie", "Enter", "Spawn", true, 265, true, "Chainsaw Sneevil");
			ExitCombat();
			bot.Quests.EnsureComplete(265);
			goto Keyone;
		G:
			if (bot.Quests.IsAvailable(264))
				goto Disguise;
			else
				goto H;
		Disguise:
			ItemFarm("Cloth Scraps", 8, "mobius", "Enter", "Spawn", true, 264, true, "Cyclops Raider");
			ExitCombat();
			bot.Quests.EnsureComplete(264);
			goto Box;
		H:
			if (bot.Quests.IsAvailable(267))
				goto Teleporter;
			else
				goto I;
		Teleporter:
			if (bot.Map.Name != "mobius".ToLower()) SafeMapJoin("mobius".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(267);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%79174%49%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(267);
			goto Disguise;
		I:
			if (bot.Quests.IsAvailable(266))
				goto Assembly;
			else
				goto J;
		Assembly:
			if (bot.Map.Name != "mobius".ToLower()) SafeMapJoin("mobius".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(266);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%79149%48%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(266);
			goto Teleporter;
		J:
			if (bot.Quests.IsAvailable(263))
				goto Framed;
			else
				goto K;
		Framed:
			if (bot.Map.Name != "cornelis".ToLower()) SafeMapJoin("cornelis".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(263);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%101508%47%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(263);
			goto Assembly;
		K:
			if (bot.Quests.IsAvailable(259))
				goto Arm;
			else
				goto L;
		Arm:
			ItemFarm("Golem Arm", 1, "cornelis", "Enter", "Spawn", true, 259, true, "Stone Golem");
			ExitCombat();
			bot.Quests.EnsureComplete(259);
			goto Framed;
		L:
			if (bot.Quests.IsAvailable(262))
				goto Quickdraw;
			else
				goto M;
		Quickdraw:
			if (bot.Map.Name != "cornelis".ToLower()) SafeMapJoin("cornelis".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(262);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%69099%46%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(262);
			goto Arm;
		M:
			if (bot.Quests.IsAvailable(258))
				goto Blue;
			else
				goto N;
		Blue:
			ItemFarm("Blue Gems", 10, "cornelis", "Enter", "Spawn", true, 258, true, "Gargoyle");
			ExitCombat();
			bot.Quests.EnsureComplete(258);
			goto Quickdraw;
		N:
			if (bot.Quests.IsAvailable(261))
				goto Energize;
			else
				goto O;
		Energize:
			if (bot.Map.Name != "cornelis".ToLower()) SafeMapJoin("cornelis".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(261);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%101354%45%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(261);
			goto Blue;
		O:
			if (bot.Quests.IsAvailable(257))
				goto Ruins;
			else
				goto P;
		Ruins:
			ItemFarm("Gargoyle Chips", 8, "cornelis", "Enter", "Spawn", true, 257, true, "Gargoyle");
			ExitCombat();
			bot.Quests.EnsureComplete(257);
			goto Energize;
		P:
			if (bot.Quests.IsAvailable(256))
				goto Second;
			else
				goto Q;
		Second:
			ItemFarm("Runed Relic", 1, "faerie", "Enter", "Spawn", true, 256, true, "Aracara");
			ExitCombat();
			bot.Quests.EnsureComplete(256);
			goto Ruins;
		Q:
			if (bot.Quests.IsAvailable(255))
				goto Tree;
			else
				goto R;
		Tree:
			ItemFarm("Warlord's Beard", 1, "faerie", "Enter", "Spawn", true, 255, true, "Cyclops Warlord");
			ExitCombat();
			bot.Quests.EnsureComplete(255);
			goto Second;
		R:
			if (bot.Quests.IsAvailable(252))
				goto Theft;
			else
				goto S;
		Theft:
			ItemFarm("Healing Jar", 1, "faerie", "Enter", "Spawn", true, 252, true, "Chainsaw Sneevil");
			ExitCombat();
			bot.Quests.EnsureComplete(252);
			goto Tree;
		S:
			if (bot.Quests.IsAvailable(251))
				goto Epic;
			else
				goto T;
		Epic:
			if (bot.Map.Name != "faerie".ToLower()) SafeMapJoin("faerie".ToLower(), "Enter", "Spawn");
			bot.Sleep(2000);
			bot.Quests.EnsureAccept(251);
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100840%43%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(251);
			goto Theft;
		T:
			if (bot.Quests.IsAvailable(250))
				goto Chain;
			else
				goto U;
		Chain:
			ItemFarm("Sneevil Chainsaw", 8, "faerie", "Enter", "Spawn", true, 250, true, "Chainsaw Sneevil");
			ExitCombat();
			bot.Quests.EnsureComplete(250);
			goto Epic;
		U:
			if (bot.Quests.IsAvailable(249))
				goto Slugfest;
			else
				goto V;
		Slugfest:
			ItemFarm("Slugfit Scalp", 1, "mobius", "Enter", "Spawn", true, 249, true, "Slugfit");
			ExitCombat();
			bot.Quests.EnsureComplete(249);
			goto Chain;
		V:
			if (bot.Quests.IsAvailable(248))
				goto Farsighted;
			else
				goto W;
		Farsighted:
			ItemFarm("Cyclops Contact Lenses", 5, "mobius", "Enter", "Spawn", true, 248, true, "Cyclops Raider");
			ExitCombat();
			bot.Quests.EnsureComplete(248);
			goto Slugfest;
		W:
			if (bot.Quests.IsAvailable(260))
				goto Miss;
			else
				goto X;
		Miss:
			if (bot.Map.Name != "mobius".ToLower()) SafeMapJoin("mobius".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(260);
			bot.Sleep(500);
			bot.SendPacket("%xt%zm%getMapItem%100635%44%");
			bot.Sleep(500);
			bot.Quests.EnsureComplete(260);
			goto Farsighted;
		X:
			if (bot.Quests.IsAvailable(247))
				goto Imp;
			else
				goto Y;
		Imp:
			ItemFarm("Imp Tooth", 5, "mobius", "Enter", "Spawn", true, 247, true, "Fire Imp");
			ExitCombat();
			bot.Quests.EnsureComplete(247);
			goto Miss;
		Y:
			if (bot.Quests.IsAvailable(246))
				goto Prisoner;
			else
				goto Z;
		Prisoner:
			if (bot.Map.Name != "mobius".ToLower()) SafeMapJoin("mobius".ToLower(), "Enter", "Spawn");
			bot.Quests.EnsureAccept(246);
			bot.Sleep(500);
			bot.SendPacket("%xt%zm%getMapItem%100483%42%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100483%42%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100483%42%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100483%42%");
			bot.Sleep(1000);
			bot.SendPacket("%xt%zm%getMapItem%100483%42%");
			bot.Sleep(1000);
			bot.Quests.EnsureComplete(246);
			goto Imp;
		Z:
			if (bot.Quests.IsAvailable(245))
				goto Spies;
			else
				goto End;
		Spies:
			ItemFarm("Eyeball Wings", 5, "mobius", "Enter", "Spawn", true, 245, true, "Chaos Sp-Eye");
			ExitCombat();
			bot.Quests.EnsureComplete(245);
			goto Prisoner;
		End:
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Script stopped successfully.");
		StopBot("Bot Failed = Pick an allegiance. Good/Evil and try again");
		End2:
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Script stopped successfully.");
		StopBot("Bot Complete! 1st Lord of Chaos has been defeated.");
		}
	}

	/*------------------------------------------------------------------------------------------------------------
													 Invokable Functions
	------------------------------------------------------------------------------------------------------------*/

	/*
		*	These functions are used to perform a major action in AQW.
		*	All of them require at least one of the Auxiliary Functions listed below to be present in your script.
		*	Some of the functions require you to pre-declare certain integers under "public class Script"
		*	ItemFarm, MultiQuestFarm and HuntItemFarm will require some Background Functions to be present as well.
		*	All of this information can be found inside the functions. Make sure to read.
		*	ItemFarm("ItemName", ItemQuantity, "MapName", "MapNumber", "CellName", "PadName", Temporary, QuestID, "MonsterName");
		*	MultiQuestFarm("MapName", "CellName", "PadName", QuestList[], "MonsterName");
		*	HuntItemFarm("ItemName", ItemQuantity, "MapName", Temporary, QuestID, "MonsterName");
		*	SafeEquip("ItemName");
		*	SafePurchase("ItemName", ItemQuantityNeeded, "MapName", "MapNumber", ShopID)
		*	SafeSell("ItemName", ItemQuantityNeeded)
		*	SafeQuestComplete(QuestID, ItemID)
		*	StopBot ("Text", "MapName", "MapNumber", "CellName", "PadName", "Caption")
	*/

	/// <summary>
	/// Farms you the specified quantity of the specified item with the specified quest accepted from specified monsters in the specified location. Saves States every ~5 minutes.
	/// </summary>
	public void ItemFarm(string ItemName, int ItemQuantity, string MapName, string CellName = "Enter", string PadName = "Spawn", bool Temporary = false, int QuestID = 0, bool HuntFor = false, string MonsterName = "*")
	{
	/*
		*   Must have the following functions in your script:
		*   SafeMapJoin
		*   SmartSaveState
		*   SkillList
		*   ExitCombat
		*   GetDropList OR ItemWhitelist
		*
		*   Must have the following commands under public class Script:
		*   int FarmLoop = 0;
		*   int SavedState = 0;
	*/

	startFarmLoop:
		if (FarmLoop > 0) goto maintainFarmLoop;
		SavedState++;
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Started Farming Loop {SavedState}.");
		goto maintainFarmLoop;

	breakFarmLoop:
		SmartSaveState();
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Completed Farming Loop {SavedState}.");
		FarmLoop = 0;
		goto startFarmLoop;

	maintainFarmLoop:
		if (Temporary)
		{
			if (HuntFor)
			{
				while (!bot.Inventory.ContainsTempItem(ItemName, ItemQuantity))
				{
					FarmLoop++;
					if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower());
					if (QuestID > 0) bot.Quests.EnsureAccept(QuestID);
					bot.Options.AggroMonsters = true;
					AttackType("h", MonsterName);
					if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
				}
			}
			else
			{
				while (!bot.Inventory.ContainsTempItem(ItemName, ItemQuantity))
				{
					FarmLoop++;
					if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
					if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
					if (QuestID > 0) bot.Quests.EnsureAccept(QuestID);
					bot.Options.AggroMonsters = true;
					AttackType("a", MonsterName);
					if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
				}
			}
		}
		else
		{
			if (HuntFor)
			{
				while (!bot.Inventory.Contains(ItemName, ItemQuantity))
				{
					FarmLoop++;
					if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower());
					if (QuestID > 0) bot.Quests.EnsureAccept(QuestID);
					bot.Options.AggroMonsters = true;
					AttackType("h", MonsterName);
					if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
				}
			}
			else
			{
				while (!bot.Inventory.Contains(ItemName, ItemQuantity))
				{
					FarmLoop++;
					if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
					if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
					if (QuestID > 0) bot.Quests.EnsureAccept(QuestID);
					bot.Options.AggroMonsters = true;
					AttackType("a", MonsterName);
					if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
				}
			}
		}
	}

	/// <summary>
	/// Farms all the quests in a given string, must all be farmable in the same room and cell.
	/// </summary>
	public void MultiQuestFarm(string MapName, string CellName, string PadName, int[] QuestList, string MonsterName = "*")
	{
	/*
		*   Must have the following functions in your script:
		*   SafeMapJoin
		*   SmartSaveState
		*   SkillList
		*   ExitCombat
		*   GetDropList OR ItemWhitelist
		*
		*   Must have the following commands under public class Script:
		*   int FarmLoop = 0;
		*   int SavedState = 0;
	*/

	startFarmLoop:
		if (FarmLoop > 0) goto maintainFarmLoop;
		SavedState++;
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Started Farming Loop {SavedState}.");
		goto maintainFarmLoop;

	breakFarmLoop:
		SmartSaveState();
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Completed Farming Loop {SavedState}.");
		FarmLoop = 0;
		goto startFarmLoop;

	maintainFarmLoop:
		FarmLoop++;
		if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
		if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
		foreach (var Quest in QuestList)
		{
			if (!bot.Quests.IsInProgress(Quest)) bot.Quests.EnsureAccept(Quest);
			if (bot.Quests.CanComplete(Quest)) SafeQuestComplete(Quest);
		}
		bot.Options.AggroMonsters = true;
		AttackType("a", MonsterName);
		if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
	}

	/// <summary>
	/// Equips an item.
	/// </summary>
	public void SafeEquip(string ItemName)
	{
		//Must have the following functions in your script:
		//ExitCombat

		while (bot.Inventory.Contains(ItemName) && !bot.Inventory.IsEquipped(ItemName))
		{
			ExitCombat();
			bot.Player.EquipItem(ItemName);
		}
	}

	/// <summary>
	/// Sets attack type to Attack(Attack/attack/A/a) or Hunt(Hunt/hunt/H/h)
	/// </summary>
	/// <param name="AttackType">Attack/attack/A/a or Hunt/hunt/H/h</param>
	/// <param name="MonsterName">Name of the monster</param>
	public void AttackType(string AttackType, string MonsterName)
	{
		if (AttackType == "A" || AttackType == "a" || AttackType == "Attack" || AttackType == "attack")
		{
			bot.Player.Attack(MonsterName);
		}
		else if (AttackType == "H" || AttackType == "h" || AttackType == "Hunt" || AttackType == "hunt")
		{
			bot.Player.Hunt(MonsterName);
		}
	}

	/// <summary>
	/// Purchases the specified quantity of the specified item from the specified shop in the specified map.
	/// </summary>
	public void SafePurchase(string ItemName, int ItemQuantityNeeded, string MapName, int ShopID)
	{
		//Must have the following functions in your script:
		//SafeMapJoin
		//ExitCombat

		while (!bot.Inventory.Contains(ItemName, ItemQuantityNeeded))
		{
			if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), "Wait", "Spawn");
			ExitCombat();
			if (!bot.Shops.IsShopLoaded)
			{
				bot.Shops.Load(ShopID);
				bot.Log($"[{DateTime.Now:HH:mm:ss}] Loaded Shop {ShopID}.");
			}
			bot.Shops.BuyItem(ItemName);
			bot.Log($"[{DateTime.Now:HH:mm:ss}] Purchased {ItemName} from Shop {ShopID}.");
		}
	}

	/// <summary>
	/// Sells the specified item until you have the specified quantity.
	/// </summary>
	public void SafeSell(string ItemName, int ItemQuantityNeeded)
	{
		//Must have the following functions in your script:
		//ExitCombat

		int sellingPoint = ItemQuantityNeeded + 1;
		while (bot.Inventory.Contains(ItemName, sellingPoint))
		{
			ExitCombat();
			bot.Shops.SellItem(ItemName);
		}
	}

	/// <summary>
	/// Attempts to complete the quest with the set amount of {TurnInAttempts}. If it fails to complete, logs out. If it successfully completes, re-accepts the quest and checks if it can be completed again.
	/// </summary>
	public void SafeQuestComplete(int QuestID, int ItemID = -1)
	{
		//Must have the following functions in your script:
		//ExitCombat

		ExitCombat();
		bot.Quests.EnsureAccept(QuestID);
		bot.Quests.EnsureComplete(QuestID, ItemID, tries: TurnInAttempts);
		if (bot.Quests.IsInProgress(QuestID))
		{
			bot.Log($"[{DateTime.Now:HH:mm:ss}] Failed to turn in Quest {QuestID}. Logging out.");
			bot.Player.Logout();
		}
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Turned In Quest {QuestID} successfully.");
		while (!bot.Quests.IsInProgress(QuestID)) bot.Quests.EnsureAccept(QuestID);
	}

	/// <summary>
	/// Stops the bot at yulgar if no parameters are set, or your specified map if the parameters are set.
	/// </summary>
	public void StopBot(string Text = "Bot stopped successfully.", string MapName = "yulgar", string CellName = "Enter", string PadName = "Spawn", string Caption = "==Finished==", string MessageType = "moderator")
	{
		//Must have the following functions in your script:
		//SafeMapJoin
		//ExitCombat
		if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
		if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
		bot.Drops.RejectElse = false;
		bot.Options.LagKiller = false;
		bot.Options.AggroMonsters = false;
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Bot stopped successfully.");
		Console.WriteLine(Text);
		SendMSGPacket(Text, Caption, MessageType);
		ScriptManager.StopScript();
	}

	/*------------------------------------------------------------------------------------------------------------
													Auxiliary Functions
	------------------------------------------------------------------------------------------------------------*/

	/*
		*   These functions are used to perform small actions in AQW.
		*   They are usually called upon by the Invokable Functions, but can be used separately as well.
		*   Make sure to have them loaded if your Invokable Function states that they are required.
		*   ExitCombat()
		*   SmartSaveState()
		*   SafeMapJoin("MapName", "CellName", "PadName")
	*/

	/// <summary>
	/// Exits Combat by jumping cells.
	/// </summary>
	public void ExitCombat()
	{
		bot.Options.AggroMonsters = false;
		bot.Player.Jump("Wait", "Spawn");
		while (bot.Player.State == 2) { }
	}

	/// <summary>
	/// Creates a quick Save State by messaging yourself.
	/// </summary>
	public void SmartSaveState()
	{
		bot.SendPacket("%xt%zm%whisper%1%creating save state%" + bot.Player.Username + "%");
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Successfully Saved State.");
	}

	/// <summary>
	/// Joins the specified map.
	/// </summary>
	public void SafeMapJoin(string MapName, string CellName = "Enter", string PadName = "Spawn")
	{
		//Must have the following functions in your script:
		//ExitCombat

		while (bot.Map.Name != MapName.ToLower())
		{
			ExitCombat();
			if (string.Equals(MapName.ToLower(), "tercessuinotlim", StringComparison.OrdinalIgnoreCase))
			{
				while (bot.Map.Name != "citadel")
				{
					bot.Player.Join($"citadel-{MapNumber}", "m22", "Left");
					bot.Wait.ForMapLoad("citadel");
					bot.Sleep(500);
				}
				if (bot.Player.Cell != "m22") bot.Player.Jump("m22", "Left");
			}
			bot.Player.Join($"{MapName.ToLower()}-{MapNumber}", CellName, PadName);
			bot.Wait.ForMapLoad(MapName.ToLower());
			bot.Sleep(500);
		}
		if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Joined map {MapName.ToLower()}-{MapNumber}, positioned at the {PadName} side of cell {CellName}.");
	}

	/*------------------------------------------------------------------------------------------------------------
													Background Functions
	------------------------------------------------------------------------------------------------------------*/

	/*
		*   These functions help you to either configure certain settings or run event handlers in the background.
		*   It is highly recommended to have all these functions present in your script as they are very useful.
		*   Some Invokable Functions may call or require the assistance of some Background Functions as well.
		*   These functions are to be run at the very beginning of the bot under public class Script.
		*   ConfigureBotOptions("PlayerName", "GuildName", LagKiller, SafeTimings, RestPackets, AutoRelogin, PrivateRooms, InfiniteRange, SkipCutscenes, ExitCombatBeforeQuest)
		*   ConfigureLiteSettings(UntargetSelf, UntargetDead, CustomDrops, ReacceptQuest, SmoothBackground, Debugger)
		*   SkillList(int[])
		*   GetDropList(string[])
		*   ItemWhiteList(string[])
		*   EquipList(string[])
		*   UnbankList(string[])
		*   CheckSpace(string[])
		*   SendMSGPacket("Message", "Name", "MessageType")
	*/

	/// <summary>
	/// Change the player's name and guild for your bots specifications.
	/// Recommended Default Bot Configurations.
	/// </summary>
	public void ConfigureBotOptions(string PlayerName = "Name Change Pog", string GuildName = "https://auqw.tk/", bool LagKiller = true, bool SafeTimings = true, bool RestPackets = true, bool AutoRelogin = true, bool PrivateRooms = false, bool InfiniteRange = true, bool SkipCutscenes = true, bool ExitCombatBeforeQuest = true)
	{
		SendMSGPacket("Configuring bot.", "AuQW", "moderator");
		bot.Options.CustomName = PlayerName;
		bot.Options.CustomGuild = GuildName;
		bot.Options.LagKiller = LagKiller;
		bot.Options.SafeTimings = SafeTimings;
		bot.Options.RestPackets = RestPackets;
		bot.Options.AutoRelogin = AutoRelogin;
		bot.Options.PrivateRooms = PrivateRooms;
		bot.Options.InfiniteRange = InfiniteRange;
		bot.Options.SkipCutscenes = SkipCutscenes;
		bot.Options.ExitCombatBeforeQuest = ExitCombatBeforeQuest;
		bot.Events.PlayerDeath += PD => ScriptManager.RestartScript();
		bot.Events.PlayerAFK += PA => ScriptManager.RestartScript();
	}

	/// <summary>
	/// Gets AQLite Functions
	/// </summary>
	/// <typeparam name="T"></typeparam>
	/// <param name="optionName"></param>
	/// <returns></returns>
	public T GetLite<T>(string optionName)
	{
		return bot.GetGameObject<T>($"litePreference.data.{optionName}");
	}

	/// <summary>
	/// Sets AQLite Functions
	/// </summary>
	/// <typeparam name="T"></typeparam>
	/// <param name="optionName"></param>
	/// <param name="value"></param>
	public void SetLite<T>(string optionName, T value)
	{
		bot.SetGameObject($"litePreference.data.{optionName}", value);
	}

	/// <summary>
	/// Allows you to turn on and off AQLite functions.
	/// Recommended Default Bot Configurations.
	/// </summary>
	public void ConfigureLiteSettings(bool UntargetSelf = true, bool UntargetDead = true, bool CustomDrops = false, bool ReacceptQuest = false, bool SmoothBackground = true, bool Debugger = false)
	{
		SetLite("bUntargetSelf", UntargetSelf);
		SetLite("bUntargetDead", UntargetDead);
		SetLite("bCustomDrops", CustomDrops);
		SetLite("bReaccept", ReacceptQuest);
		SetLite("bSmoothBG", SmoothBackground);
		SetLite("bDebugger", Debugger);
	}

	/// <summary>
	/// Spams Skills when in combat. You can get in combat by going to a cell with monsters in it with bot.Options.AggroMonsters enabled or using an attack command against one.
	/// </summary>
	public void SkillList(params int[] Skillset)
	{
		bot.RegisterHandler(1, b => {
			if (bot.Player.InCombat)
			{
				foreach (var Skill in Skillset)
				{
					bot.Player.UseSkill(Skill);
				}
			}
		});
	}

	/// <summary>
	/// Checks if items in an array have dropped every second and picks them up if so. GetDropList is recommended.
	/// </summary>
	public void GetDropList(params string[] GetDropList)
	{
		bot.RegisterHandler(4, b => {
			foreach (string Item in GetDropList)
			{
				if (bot.Player.DropExists(Item)) bot.Player.Pickup(Item);
			}
			bot.Player.RejectExcept(GetDropList);
		});
	}

	/// <summary>
	/// Pick up items in an array when they dropped. May fail to pick up items that drop immediately after the same item is picked up. GetDropList is preferable instead.
	/// </summary>
	public void ItemWhiteList(params string[] WhiteList)
	{
		foreach (var Item in WhiteList)
		{
			bot.Drops.Add(Item);
		}
		bot.Drops.RejectElse = true;
		bot.Drops.Start();
	}

	/// <summary>
	/// Equips all items in an array.
	/// </summary>
	/// <param name="EquipList"></param>
	public void EquipList(params string[] EquipList)
	{
		foreach (var Item in EquipList)
		{
			if (bot.Inventory.Contains(Item))
			{
				SafeEquip(Item);
			}
		}
	}

	/// <summary>
	/// Unbanks all items in an array after banking every other AC-tagged Misc item in the inventory.
	/// </summary>
	/// <param name="UnbankList"></param>
	public void UnbankList(params string[] UnbankList)
	{
		if (bot.Player.Cell != "Wait") bot.Player.Jump("Wait", "Spawn");
		while (bot.Player.State == 2) { }
		bot.Player.LoadBank();
		List<string> Whitelisted = new List<string>() { "Note", "Item", "Resource", "QuestItem", "ServerUse" };
		foreach (var item in bot.Inventory.Items)
		{
			if (!Whitelisted.Contains(item.Category.ToString())) continue;
			if (item.Name != "Treasure Potion" && item.Coins && !Array.Exists(UnbankList, x => x == item.Name)) bot.Inventory.ToBank(item.Name);
		}
		foreach (var item in UnbankList)
		{
			if (bot.Bank.Contains(item)) bot.Bank.ToInventory(item);
		}
	}

	/// <summary>
	/// Checks the amount of space you need from an array's length/set amount.
	/// </summary>
	/// <param name="ItemList"></param>
	public void CheckSpace(params string[] ItemList)
	{
		int MaxSpace = bot.GetGameObject<int>("world.myAvatar.objData.iBagSlots");
		int FilledSpace = bot.GetGameObject<int>("world.myAvatar.items.length");
		int EmptySpace = MaxSpace - FilledSpace;
		int SpaceNeeded = 0;

		foreach (var Item in ItemList)
		{
			if (!bot.Inventory.Contains(Item)) SpaceNeeded++;
		}

		if (EmptySpace < SpaceNeeded)
		{
			StopBot($"Need {SpaceNeeded} empty inventory slots, please make room for the quest.", bot.Map.Name, bot.Player.Cell, bot.Player.Pad, "Error", "moderator");
		}
	}

	/// <summary>
	/// Sends a message packet to client in chat.
	/// </summary>
	/// <param name="Message"></param>
	/// <param name="Name"></param>
	/// <param name="MessageType">moderator, warning, server, event, guild, zone, whisper</param>
	public void SendMSGPacket(string Message = " ", string Name = "SERVER", string MessageType = "zone")
	{
		// bot.SendClientPacket($"%xt%{MessageType}%-1%{Name}: {Message}%");
		bot.SendClientPacket($"%xt%chatm%0%{MessageType}~{Message}%{Name}%");
	}
}
