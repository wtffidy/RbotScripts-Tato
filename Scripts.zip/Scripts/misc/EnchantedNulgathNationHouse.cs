using System;
using RBot;
using System.Collections.Generic;

/*
	note#0227
	https://auqw.tk/
	https://discord.io/AQWBots
*/

public class BluuPurpleTemplate
{
	//Edit "START"
	public int MapNumber = 2142069; //default = 2142069
	public int ScriptDelay = 700;   //default = 700
	public readonly int[] SkillOrder = { 3, 1, 2, 4 };
	public string SoloingClass = "Legion Revenant";
	public string FarmingClass = "Legion Revenant";
	//Edit " END "

/* Don't edit anything below this text if you don't know what are you doing. */

	public string[] RequiredItems = { 
		"Enchanted Nulgath Nation House",
		"Nulgath Nation House",
		"Musgravite of Nulgath",
		"Pink Star Diamond of Nulgath",
		"NUE Necronomicon",
		"Unidentified 10",
		"Unidentified 13",
		"Tainted Gem",
		"Dark Crystal Shard",
		"Diamond of Nulgath",
		"Voucher of Nulgath (non-mem)",
		"Totem of Nulgath",
		"Gem of Nulgath",
		"Cemaros' Amethyst",
		"Aluminum",
		"Nulgath's Approval",
		"Blood Gem of the Archfiend"
	};
	public string[] EquippedItems = { };
	public int SaveStateLoops = 8700;
	public int TurnInAttempts = 10;
	public int FarmLoop;
	public int SavedState;
	public ScriptInterface bot => ScriptInterface.Instance;
	public void ScriptMain(ScriptInterface bot)
	{
		if (bot.Player.Cell != "Wait") bot.Player.Jump("Wait", "Spawn");

		DeathHandler();
		ConfigureBotOptions();
		ConfigureLiteSettings();
		SkillList(SkillOrder);
		EquipList(EquippedItems);
		UnbankList(RequiredItems);
		CheckSpace(RequiredItems);
		GetDropList(RequiredItems);

		while (!bot.ShouldExit())
		{
			while (!bot.Player.Loaded) { }
			
			//check
			if(bot.Inventory.Contains("Enchanted Nulgath Nation House")) StopBot("You already have Enchanted Nulgath Nation House.");
			if(!bot.Inventory.Contains("NUE Necronomicon"))
			{
				while(bot.Player.GetFactionRank("DoomWood") < 10)
				{
					bot.Quests.EnsureAccept(1123);
					
					if(!bot.Quests.CanComplete(1123))
					{
						SafeEquip(FarmingClass);
						ItemFarm("Slimeskull Trophy", 5, true, "temple", "r2", "Up");
						ItemFarm("Muched Boneshard", 5, true, "temple", "r2", "Up");
						ItemFarm("Shelleton Shrapnel", 5, true, "temple", "r2", "Up");
					}
					else SafeQuestComplete(1123);
					bot.Sleep(ScriptDelay);
				}
				SafePurchase("NUE Necronomicon", 1, "lightguard", 277);
			}
			
			//script
			while(!bot.Inventory.Contains("Enchanted Nulgath Nation House"))
			{
				if(!bot.Inventory.Contains("Nulgath Nation House"))
				{
					bot.Quests.EnsureAccept(4779);
					
					if(!bot.Quests.CanComplete(4779))
					{
						//voucher
						if(!bot.Inventory.Contains("Voucher of Nulgath (non-mem)")) Larvae("Voucher of Nulgath (non-mem)", 1);
						//uni13
						if(!bot.Inventory.Contains("Unidentified 13")) Larvae("Unidentified 13", 1);
						//dark crystal shard
						if(!bot.Inventory.Contains("Dark Crystal Shard", 250)) Larvae("Dark Crystal Shard", 250);
						//diamond
						if(!bot.Inventory.Contains("Diamond of Nulgath")) Larvae("Diamond of Nulgath", 300);
						//totem
						if(!bot.Inventory.Contains("Totem of Nulgath", 30)) VoucherItem("Totem of Nulgath", 5357, 30);
						//gem
						if(!bot.Inventory.Contains("Gem of Nulgath", 150)) VoucherItem("Gem of Nulgath", 6136, 150);
						
						//blood gem
						if(!bot.Inventory.Contains("Blood Gem of the Archfiend", 100))
						{
							string[] BloodGem = {
								"Escherion's Helm",
								"Shattered Legendary Sword of Dragon Control",
								"Hydra Scale Piece",
								"Blood Gem of the Archfiend"
							};
							
							UnbankList(BloodGem);
							GetDropList(BloodGem);
							
							bot.Quests.EnsureAccept(7816);
							
							if(!bot.Quests.CanComplete(7816))
							{
								SafeEquip(SoloingClass);
								ItemFarm("Escherion's Helm", 1, false, "escherion", "Boss", "Left");
								ItemFarm("Shattered Legendary Sword of Dragon Control", 1, false, "stalagbite", "r2", "Left");
								
								SafeEquip(FarmingClass);
								ItemFarm("Hydra Scale Piece", 200, false, "hydrachallenge", "h85");
							}
							else SafeQuestComplete(7816);
							bot.Sleep(ScriptDelay);
						}
						
						//cemaros amethyst
						if(!bot.Inventory.Contains("Cemaros's Amethyst"))
						{
							if(bot.Player.GetFactionRank("Chaos") < 2)
							{
								bot.Quests.EnsureAccept(3594);
								
								if(!bot.Quests.CanComplete(3594))
								{
									SafeEquip(FarmingClass);
									ItemFarm("Chaos Power Increased", 6, true, "mountdoomskull", "b10", "Left");
								}
								else SafeQuestComplete(3594);
								bot.Sleep(ScriptDelay);
							}
							SafePurchase("Cemaros' Amethyst", 1, "mountdoomskull", 776);
						}
						
						//nulgath's approval
						if(!bot.Inventory.Contains("Nulgath's Approval", 1000))
						{
							SafeEquip(FarmingClass);
							ItemFarm("Nulgath's Approval", 1000, false, "evilwarnul", "r9", "Left");
						}
						
						//aluminum
						if(!bot.Inventory.Contains("Aluminum"))
						{
							string[] Minecrafting = {
								"Axe of the Prospector",
								"Aluminum"
							};
							
							UnbankList(Minecrafting);
							GetDropList(Minecrafting);
							
							if(bot.Quests.IsDailyComplete(2091))
							{
								StopBot("Run the script again tomorrow Minecrafting Quest is can be only completed once a day.");
							}
							else bot.Quests.EnsureAccept(2091);
							
							if(!bot.Quests.CanComplete(2091))
							{
								SafeEquip(FarmingClass);
								ItemFarm("Axe of the Prospector", 1, false, "stalagbite");
								ItemFarm("Raw Ore", 30, true, "stalagbite");
							}
							else SafeQuestComplete(2091, 11608);
							bot.Sleep(ScriptDelay);
						}
					}
					else
					{
						bot.Sleep(ScriptDelay);
					
						UnbankList(RequiredItems);
						CheckSpace(RequiredItems);
						GetDropList(RequiredItems);
						
						SafeQuestComplete(4779);
					}
					bot.Sleep(ScriptDelay);
				}
				
				//musgravite of nulgath
				if(!bot.Inventory.Contains("Musgravite of Nulgath", 2))
				{
					SafeEquip(FarmingClass);
					ItemFarm("Musgravite of Nulgath", 2, false, "timelibrary", "Frame9", "Left");
				}
				
				//pink star diamond of nulgath
				if(!bot.Inventory.Contains("Pink Star Diamond of Nulgath"))
				{
					SafeEquip(FarmingClass);
					ItemFarm("Pink Star Diamond of Nulgath", 1, false, "guru", "Field2", "Left");
				}
				bot.Sleep(5000);
				SafePurchase("Enchanted Nulgath Nation House", 1, "archportal", 1211);
				bot.Sleep(5000);
			}
			break;
		}
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Script stopped successfully.");
		StopBot($"Successfully farmed Enchanted Nulgath Nation House.");
	}
	
	public void Larvae(string ItemName, int ItemQty)
	{
		string[] Larvae = {
			"Mana Energy for Nulgath",
			"Unidentified 10",
			"Unidentified 13",
			"Tainted Gem",
			"Dark Crystal Shard",
			"Diamond of Nulgath",
			"Voucher of Nulgath (non-mem)",
			"Totem of Nulgath",
			"Gem of Nulgath",
			"Blood Gem of the Archfiend"
		};
		
		UnbankList(Larvae);
		GetDropList(Larvae);
		



		while(!bot.Inventory.Contains(ItemName, ItemQty))
		{
			bot.Quests.EnsureAccept(2566);
			
			if(!bot.Quests.CanComplete(2566))
			{
				SafeEquip(SoloingClass);
				ItemFarm("Mana Energy for Nulgath", 1, false, true, 2566, "Mana Golem", "elemental");
				
				SafeEquip(FarmingClass);
				ItemFarm("Charged Mana Energy for Nulgath", 5, true, true, 2566, "Mana Falcon|Mana Imp", "elemental");
			}
			else SafeQuestComplete(2566);
			bot.Sleep(ScriptDelay);
		}
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Successfully farmed {ItemQty}x {ItemName}.");
	}
	
	public void VoucherItem(string ItemName, int ItemID, int ItemQty)
	{
		string[] VoucherItem = {
			"Essence of Nulgath",
			"Totem of Nulgath",
			"Gem of Nulgath"
		};
		
		UnbankList(VoucherItem);
		GetDropList(VoucherItem);
		
		while(!bot.Inventory.Contains(ItemName, ItemQty))
		{
			bot.Quests.EnsureAccept(4778);
		
			if(!bot.Quests.CanComplete(4778))
			{
				ItemFarm("Essence of Nulgath", 60, false, "tercessuinotlim", "m2", "Down");
			}
			else SafeQuestComplete(4778, ItemID);
			bot.Sleep(ScriptDelay);
		}
	}

//INVOKABLE FUNCTION

	public void ItemFarm(string ItemName, int ItemQuantity, bool Temporary = false, string MapName = "Map", string CellName = "Enter", string PadName = "Spawn", int QuestID = 0, string MonsterName = "*")
	{
	
	startFarmLoop:
		if (FarmLoop > 0) goto maintainFarmLoop;
		SavedState++;
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Started Farming Loop {SavedState}.");
		goto maintainFarmLoop;

	breakFarmLoop:
		SmartSaveState();
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Completed Farming Loop {SavedState}.");
		FarmLoop = 0;
		goto startFarmLoop;

	maintainFarmLoop:
		if (Temporary)
		{
			while (!bot.Inventory.ContainsTempItem(ItemName, ItemQuantity))
			{
				FarmLoop++;
				if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
				if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
				if (QuestID > 0) bot.Quests.EnsureAccept(QuestID);
				bot.Options.AggroMonsters = true;
				bot.Player.Attack(MonsterName);
				if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
			}
		}
		else
		{
			while (!bot.Inventory.Contains(ItemName, ItemQuantity))
			{
				FarmLoop++;
				if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
				if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
				if (QuestID > 0) bot.Quests.EnsureAccept(QuestID);
				bot.Options.AggroMonsters = true;
				bot.Player.Attack(MonsterName);
				if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
			}
		}
	}


	public void MultiQuestFarm(string MapName, string CellName, string PadName, int[] QuestList, string MonsterName = "*")
	{
	
	startFarmLoop:
		if (FarmLoop > 0) goto maintainFarmLoop;
		SavedState++;
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Started Farming Loop {SavedState}.");
		goto maintainFarmLoop;

	breakFarmLoop:
		SmartSaveState();
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Completed Farming Loop {SavedState}.");
		FarmLoop = 0;
		goto startFarmLoop;

	maintainFarmLoop:
		FarmLoop++;
		if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
		if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
		foreach (var Quest in QuestList)
		{
			if (!bot.Quests.IsInProgress(Quest)) bot.Quests.EnsureAccept(Quest);
			if (bot.Quests.CanComplete(Quest)) SafeQuestComplete(Quest);
		}
		bot.Options.AggroMonsters = true;
		bot.Player.Attack(MonsterName);
		if (FarmLoop > SaveStateLoops) goto breakFarmLoop;
	}


	public void SafeEquip(string ItemName)
	{
		while (bot.Inventory.Contains(ItemName) && !bot.Inventory.IsEquipped(ItemName))
		{
			ExitCombat();
			bot.Player.EquipItem(ItemName);
		}
	}


	public void SafePurchase(string ItemName, int ItemQuantityNeeded, string MapName, int ShopID)
	{
		while (!bot.Inventory.Contains(ItemName, ItemQuantityNeeded))
		{
			if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), "Wait", "Spawn");
			ExitCombat();
			if (!bot.Shops.IsShopLoaded)
			{
				bot.Shops.Load(ShopID);
				bot.Log($"[{DateTime.Now:HH:mm:ss}] Loaded Shop {ShopID}.");
			}
			bot.Shops.BuyItem(ItemName);
			bot.Log($"[{DateTime.Now:HH:mm:ss}] Purchased {ItemName} from Shop {ShopID}.");
		}
	}


	public void SafeSell(string ItemName, int ItemQuantityNeeded)
	{
		int sellingPoint = ItemQuantityNeeded + 1;
		while (bot.Inventory.Contains(ItemName, sellingPoint))
		{
			ExitCombat();
			bot.Shops.SellItem(ItemName);
		}
	}


	public void SafeQuestComplete(int QuestID, int ItemID = -1)
	{
		ExitCombat();
		bot.Quests.EnsureAccept(QuestID);
		bot.Quests.EnsureComplete(QuestID, ItemID, tries: TurnInAttempts);
		if (bot.Quests.IsInProgress(QuestID))
		{
			bot.Log($"[{DateTime.Now:HH:mm:ss}] Failed to turn in Quest {QuestID}. Logging out.");
			bot.Player.Logout();
		}
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Turned In Quest {QuestID} successfully.");
		while (!bot.Quests.IsInProgress(QuestID)) bot.Quests.EnsureAccept(QuestID);
	}


	public void StopBot(string Text = "Bot stopped successfully.", string Caption = "Stopped", string MessageType = "event", string MapName = "theater", string CellName = "Enter", string PadName = "Spawn")
	{
		if (bot.Map.Name != MapName.ToLower()) SafeMapJoin(MapName.ToLower(), CellName, PadName);
		if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
		bot.Drops.RejectElse = false;
		bot.Options.LagKiller = false;
		bot.Options.AggroMonsters = false;
		SetLite("bCustomDrops", true);
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Bot stopped successfully.");
		Console.WriteLine(Text);
		SendMSGPacket(Text, Caption, MessageType);
		ScriptManager.StopScript();
	}

//AUXILLARY FUNCTION

	public void ExitCombat()
	{
		bot.Options.AggroMonsters = false;
		bot.Player.Jump("Wait", "Spawn");
		while (bot.Player.State == 2) { }
	}


	public void SmartSaveState()
	{
		bot.SendPacket("%xt%zm%whisper%1%creating save state%" + bot.Player.Username + "%");
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Successfully Saved State.");
	}


	public void SafeMapJoin(string MapName, string CellName = "Enter", string PadName = "Spawn")
	{
		string mapname = MapName.ToLower();
		while (bot.Map.Name != mapname)
		{
			ExitCombat();
			if (mapname == "tercessuinotlim") bot.Player.Jump("m22", "Center");
			bot.Player.Join($"{mapname}-{MapNumber}", CellName, PadName);
			bot.Wait.ForMapLoad(mapname);
			bot.Sleep(500);
		}
		if (bot.Player.Cell != CellName) bot.Player.Jump(CellName, PadName);
		bot.Log($"[{DateTime.Now:HH:mm:ss}] Joined map {mapname}-{MapNumber}, positioned at the {PadName} side of cell {CellName}.");
	}

//BACKGROUND FUNCTION

	public void ConfigureBotOptions(string PlayerName = "Note POG", string GuildName = "<Note's Seks Slave>", bool LagKiller = true, bool SafeTimings = true, bool RestPackets = true, bool AutoRelogin = true, bool PrivateRooms = false, bool InfiniteRange = true, bool SkipCutscenes = true, bool ExitCombatBeforeQuest = true, bool HideMonster=true)
	{
		SendMSGPacket("Configuring script.", "Note", "moderator");
		bot.Options.CustomName = PlayerName;
		bot.Options.CustomGuild = GuildName;
		bot.Options.LagKiller = LagKiller;
		bot.Options.SafeTimings = SafeTimings;
		bot.Options.RestPackets = RestPackets;
		bot.Options.AutoRelogin = AutoRelogin;
		bot.Options.PrivateRooms = PrivateRooms;
		bot.Options.InfiniteRange = InfiniteRange;
		bot.Options.SkipCutscenes = SkipCutscenes;
		bot.Options.ExitCombatBeforeQuest = ExitCombatBeforeQuest;
		// bot.Events.PlayerDeath += PD => ScriptManager.RestartScript();
		// bot.Events.PlayerAFK += PA => ScriptManager.RestartScript();
		HideMonsters(HideMonster);
	}


	public void HideMonsters(bool Value) {
	  switch(Value) {
	     case true:
	        if (!bot.GetGameObject<bool>("ui.monsterIcon.redX.visible")) {
	           bot.CallGameFunction("world.toggleMonsters");
	        }
	        return;
	     case false:
	        if (bot.GetGameObject<bool>("ui.monsterIcon.redX.visible")) {
	           bot.CallGameFunction("world.toggleMonsters");
	        }
	        return;
	  }
	}


	public T GetLite<T>(string optionName)
	{
		return bot.GetGameObject<T>($"litePreference.data.{optionName}");
	}


	public void SetLite<T>(string optionName, T value)
	{
		bot.SetGameObject($"litePreference.data.{optionName}", value);
	}


	public void ConfigureLiteSettings(bool UntargetSelf = true, bool UntargetDead = true, bool CustomDrops = false, bool ReacceptQuest = false, bool SmoothBackground = true, bool Debugger = false)
	{
		SetLite("bUntargetSelf", UntargetSelf);
		SetLite("bUntargetDead", UntargetDead);
		SetLite("bCustomDrops", CustomDrops);
		SetLite("bReaccept", ReacceptQuest);
		SetLite("bSmoothBG", SmoothBackground);
		SetLite("bDebugger", Debugger);
	}


	public void SkillList(params int[] Skillset)
	{
		bot.RegisterHandler(1, b => {
			if (bot.Player.InCombat)
			{
				foreach (var Skill in Skillset)
				{
					bot.Player.UseSkill(Skill);
				}
			}
		});
	}


	public void GetDropList(params string[] GetDropList)
	{
		bot.RegisterHandler(4, b => {
			foreach (string Item in GetDropList)
			{
				if (bot.Player.DropExists(Item)) bot.Player.Pickup(Item);
			}
			bot.Player.RejectExcept(GetDropList);
		});
	}


	public void ItemWhiteList(params string[] WhiteList)
	{
		foreach (var Item in WhiteList)
		{
			bot.Drops.Add(Item);
		}
		bot.Drops.RejectElse = true;
		bot.Drops.Start();
	}


	public void EquipList(params string[] EquipList)
	{
		foreach (var Item in EquipList)
		{
			if (bot.Inventory.Contains(Item))
			{
				SafeEquip(Item);
			}
		}
	}


	public void UnbankList(params string[] UnbankList)
	{
		if (bot.Player.Cell != "Wait") bot.Player.Jump("Wait", "Spawn");
		while (bot.Player.State == 2) { }
		bot.Player.LoadBank();
		List<string> Whitelisted = new List<string>() { "Note", "Item", "Resource", "QuestItem", "ServerUse" };
		foreach (var item in bot.Inventory.Items)
		{
			if (!Whitelisted.Contains(item.Category.ToString())) continue;
			if (item.Name != "Treasure Potion" && item.Coins && !Array.Exists(UnbankList, x => x == item.Name)) bot.Inventory.ToBank(item.Name);
		}
		foreach (var item in UnbankList)
		{
			if (bot.Bank.Contains(item)) bot.Bank.ToInventory(item);
		}
	}


	public void CheckSpace(params string[] ItemList)
	{
		int MaxSpace = bot.GetGameObject<int>("world.myAvatar.objData.iBagSlots");
		int FilledSpace = bot.GetGameObject<int>("world.myAvatar.items.length");
		int EmptySpace = MaxSpace - FilledSpace;
		int SpaceNeeded = 0;

		foreach (var Item in ItemList)
		{
			if (!bot.Inventory.Contains(Item)) SpaceNeeded++;
		}

		if (EmptySpace < SpaceNeeded)
		{
			StopBot($"Need {SpaceNeeded} empty inventory slots, please make room for the quest.", bot.Map.Name, bot.Player.Cell, bot.Player.Pad, "Error", "moderator");
		}
	}


	public void SendMSGPacket(string Message = " ", string Name = "SERVER", string MessageType = "zone")
	{
		// bot.SendClientPacket($"%xt%{MessageType}%-1%{Name}: {Message}%");
		bot.SendClientPacket($"%xt%chatm%0%{MessageType}~{Message}%{Name}%");
	}


	public void DeathHandler() {
      bot.RegisterHandler(2, b => {
         if (bot.Player.State==0) {
            bot.Player.SetSpawnPoint();
            ExitCombat();
            bot.Sleep(12000);
         }
      });
	}
}