using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
	// Setup options
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		bot.Options.LagKiller = true;
		bot.Options.InfiniteRange = true;
		bot.Options.HuntDelay = 1000;
	//Accept Quest
		bot.Quests.EnsureAccept(8362);
	//Skills
		bot.Skills.StartTimer();
	//Join
		bot.Player.Join("queenbattle");
	//Battle
		bot.Player.HuntForItem("Proto Chaos Champion", "Proto Chaos Champion Redefeated", 1, true);
		bot.Player.HuntForItem("Queen of Monsters", "Queen of Monsters Resealed", 1, true);
	// Turn in quest and get reward.
        bot.Quests.EnsureComplete(8362);
        bot.Wait.ForDrop("Severed Tentacle");
        bot.Player.Pickup("Severed Tentacle");
        
    // Repeat
    	while(!bot.ShouldExit()){
    	//Accept Quest
		bot.Quests.EnsureAccept(8362);
	//Join
		bot.Player.Join("queenbattle");
	//Battle
		bot.Player.HuntForItem("Proto Chaos Champion", "Proto Chaos Champion Redefeated", 1, true);
		bot.Player.HuntForItem("Queen of Monsters", "Queen of Monsters Resealed", 1, true);
	// Turn in quest and get reward.
        bot.Quests.EnsureComplete(8362);
        bot.Wait.ForDrop("Severed Tentacle");
        bot.Player.Pickup("Severed Tentacle");
	}
	
}
}
